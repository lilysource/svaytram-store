/* ============================================================
   TestimonialsSection — DonutCraft Store
   Design: Scrolling testimonial cards
   ============================================================ */

const testimonials = [
  { name: "SarahP_88", role: "Player", text: "Awesome shop, fastest delivery and quality. Got my MVP rank in under 5 minutes!", avatar: "S", color: "#a855f7" },
  { name: "TacticalGamer", role: "Player", text: "Top quality items and money, would recommend to everyone on the server.", avatar: "T", color: "#06b6d4" },
  { name: "Mikes_2", role: "Bulk Buyer", text: "Actually legit. Bought 500M and it was in my account instantly. 10/10.", avatar: "M", color: "#f59e0b" },
  { name: "Kian24", role: "Loyal Customer", text: "Top quality. Been trying to grind, but this boosted me so much. 10/10.", avatar: "K", color: "#22c55e" },
  { name: "SharoUin", role: "Player", text: "Very easy delivery, very fast. The LEGEND rank is totally worth it!", avatar: "S", color: "#f97316" },
  { name: "xXProGamer", role: "VIP Member", text: "Best store I've used. Staff is super helpful and delivery is always fast.", avatar: "X", color: "#6366f1" },
];

function StarRating() {
  return (
    <div className="flex gap-0.5">
      {Array(5).fill(null).map((_, i) => (
        <span key={i} className="text-yellow-400 text-sm">★</span>
      ))}
    </div>
  );
}

export default function TestimonialsSection() {
  return (
    <section className="py-20">
      <div className="container mx-auto px-4 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-semibold text-purple-300 mb-4"
            style={{ background: "rgba(124,58,237,0.15)", border: "1px solid rgba(168,85,247,0.25)" }}>
            Testimonials
          </div>
          <h2 className="text-3xl md:text-4xl font-black text-white mb-3" style={{ fontFamily: "'Exo 2', sans-serif" }}>
            Loved by the{" "}
            <span style={{
              backgroundImage: "linear-gradient(135deg, #a855f7, #7c3aed)",
              WebkitBackgroundClip: "text",
              WebkitTextFillColor: "transparent",
              backgroundClip: "text",
            }}>
              Community
            </span>
          </h2>
          <p className="text-gray-400">Trusted by over 2,500+ players worldwide</p>
        </div>

        {/* Testimonial grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {testimonials.map((t, i) => (
            <div
              key={t.name}
              className="fade-up p-5 rounded-xl flex flex-col gap-3"
              style={{
                animationDelay: `${i * 80}ms`,
                background: "linear-gradient(145deg, rgba(20,20,35,0.8), rgba(15,15,28,0.9))",
                border: "1px solid rgba(255,255,255,0.06)",
              }}
            >
              <StarRating />
              <p className="text-gray-300 text-sm leading-relaxed flex-1">"{t.text}"</p>
              <div className="flex items-center gap-3 pt-2 border-t border-white/5">
                <div className="w-9 h-9 rounded-full flex items-center justify-center text-white font-bold text-sm shrink-0"
                  style={{ background: `${t.color}30`, border: `1px solid ${t.color}50`, color: t.color }}>
                  {t.avatar}
                </div>
                <div>
                  <div className="text-white font-semibold text-sm">{t.name}</div>
                  <div className="text-gray-500 text-xs">{t.role}</div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
