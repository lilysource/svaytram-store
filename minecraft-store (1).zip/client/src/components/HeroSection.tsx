/* ============================================================
   HeroSection — DonutCraft Store
   Design: Full-width hero with purple gradient, hero image, animated stats
   ============================================================ */
import { useEffect, useState } from "react";
import { HERO_IMG } from "@/lib/storeData";

function AnimatedCounter({ target, suffix = "" }: { target: number; suffix?: string }) {
  const [count, setCount] = useState(0);

  useEffect(() => {
    let start = 0;
    const duration = 1800;
    const step = target / (duration / 16);
    const timer = setInterval(() => {
      start += step;
      if (start >= target) {
        setCount(target);
        clearInterval(timer);
      } else {
        setCount(Math.floor(start));
      }
    }, 16);
    return () => clearInterval(timer);
  }, [target]);

  return (
    <span>{count.toLocaleString()}{suffix}</span>
  );
}

interface HeroSectionProps {
  onShopNow: (cat: "ranks" | "money") => void;
}

export default function HeroSection({ onShopNow }: HeroSectionProps) {
  return (
    <section className="relative overflow-hidden" style={{ minHeight: "520px" }}>
      {/* Background */}
      <div className="absolute inset-0">
        <img
          src={HERO_IMG}
          alt="DonutCraft Store Hero"
          className="w-full h-full object-cover object-center"
        />
        <div className="absolute inset-0" style={{
          background: "linear-gradient(90deg, rgba(10,10,20,0.92) 0%, rgba(10,10,20,0.7) 50%, rgba(10,10,20,0.5) 100%)"
        }} />
        <div className="absolute inset-0" style={{
          background: "linear-gradient(to top, rgba(10,10,20,1) 0%, transparent 40%)"
        }} />
        {/* Purple glow overlay */}
        <div className="absolute inset-0" style={{
          background: "radial-gradient(ellipse at 20% 50%, rgba(124,58,237,0.15) 0%, transparent 60%)"
        }} />
      </div>

      {/* Content */}
      <div className="relative container mx-auto px-4 lg:px-8 py-20 flex flex-col justify-center" style={{ minHeight: "520px" }}>
        <div className="max-w-2xl">
          {/* Badge */}
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-semibold text-purple-300 mb-6"
            style={{ background: "rgba(124,58,237,0.2)", border: "1px solid rgba(168,85,247,0.3)" }}>
            <span className="w-2 h-2 rounded-full bg-green-400 animate-pulse"></span>
            Server Online — donutcraft.net
          </div>

          {/* Headline */}
          <h1 className="text-5xl md:text-6xl lg:text-7xl font-black text-white leading-none mb-4"
            style={{ fontFamily: "'Exo 2', sans-serif" }}>
            The #1
            <br />
            <span style={{
              backgroundImage: "linear-gradient(135deg, #a855f7, #7c3aed, #6366f1)",
              WebkitBackgroundClip: "text",
              WebkitTextFillColor: "transparent",
              backgroundClip: "text",
            }}>
              Minecraft Store
            </span>
          </h1>

          <p className="text-gray-300 text-lg mb-8 max-w-lg leading-relaxed">
            Buy exclusive <strong className="text-white">ranks</strong> and{" "}
            <strong className="text-yellow-400">in-game money</strong> with instant delivery.
            Dominate the server economy today.
          </p>

          {/* CTA buttons */}
          <div className="flex flex-wrap gap-3">
            <button
              onClick={() => onShopNow("ranks")}
              className="flex items-center gap-2 px-6 py-3.5 rounded-xl text-white font-bold text-base btn-glow"
              style={{ fontFamily: "'Exo 2', sans-serif" }}
            >
              ⚔️ Browse Ranks
            </button>
            <button
              onClick={() => onShopNow("money")}
              className="flex items-center gap-2 px-6 py-3.5 rounded-xl font-bold text-base transition-all hover:bg-white/10"
              style={{
                background: "rgba(255,255,255,0.06)",
                border: "1px solid rgba(255,255,255,0.12)",
                color: "white",
                fontFamily: "'Exo 2', sans-serif",
              }}
            >
              💰 Buy Money
            </button>
          </div>

          {/* Stats */}
          <div className="flex flex-wrap gap-8 mt-10">
            <div>
              <div className="text-3xl font-black text-white" style={{ fontFamily: "'Exo 2', sans-serif" }}>
                <AnimatedCounter target={2500} suffix="+" />
              </div>
              <div className="text-xs text-gray-400 font-medium uppercase tracking-wider mt-0.5">Happy Customers</div>
            </div>
            <div className="w-px bg-white/10 self-stretch" />
            <div>
              <div className="text-3xl font-black text-white" style={{ fontFamily: "'Exo 2', sans-serif" }}>
                <AnimatedCounter target={1} suffix="-10 Mins" />
              </div>
              <div className="text-xs text-gray-400 font-medium uppercase tracking-wider mt-0.5">Fast Delivery</div>
            </div>
            <div className="w-px bg-white/10 self-stretch" />
            <div>
              <div className="text-3xl font-black text-white" style={{ fontFamily: "'Exo 2', sans-serif" }}>
                24/7
              </div>
              <div className="text-xs text-gray-400 font-medium uppercase tracking-wider mt-0.5">Support</div>
            </div>
          </div>
        </div>
      </div>

      {/* Wave divider */}
      <div className="absolute bottom-0 left-0 right-0">
        <svg viewBox="0 0 1440 60" fill="none" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="none" style={{ display: "block" }}>
          <path d="M0,30 C360,60 1080,0 1440,30 L1440,60 L0,60 Z" fill="rgba(10,10,20,1)" />
        </svg>
      </div>
    </section>
  );
}
