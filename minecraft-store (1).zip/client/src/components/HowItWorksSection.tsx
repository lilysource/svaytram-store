/* ============================================================
   HowItWorksSection — DonutCraft Store
   Design: Step-by-step process with numbered cards
   ============================================================ */

const steps = [
  {
    step: "01",
    icon: "🛒",
    title: "Choose a Package",
    description: "Browse our ranks and money packages. Select the one that fits your playstyle and budget.",
    color: "#7c3aed",
  },
  {
    step: "02",
    icon: "💳",
    title: "Secure Checkout",
    description: "Complete your purchase through our secure payment system. We accept all major cards and PayPal.",
    color: "#06b6d4",
  },
  {
    step: "03",
    icon: "⚡",
    title: "Instant Delivery",
    description: "Your rank or money is delivered to your account within minutes. No waiting, no hassle.",
    color: "#22c55e",
  },
  {
    step: "04",
    icon: "🎮",
    title: "Enjoy the Game",
    description: "Log in to the server and enjoy your new rank or money. Dominate the economy!",
    color: "#f59e0b",
  },
];

export default function HowItWorksSection() {
  return (
    <section className="py-20">
      <div className="container mx-auto px-4 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-semibold text-purple-300 mb-4"
            style={{ background: "rgba(124,58,237,0.15)", border: "1px solid rgba(168,85,247,0.25)" }}>
            How It Works
          </div>
          <h2 className="text-3xl md:text-4xl font-black text-white mb-3" style={{ fontFamily: "'Exo 2', sans-serif" }}>
            Get Started in{" "}
            <span style={{
              backgroundImage: "linear-gradient(135deg, #a855f7, #7c3aed)",
              WebkitBackgroundClip: "text",
              WebkitTextFillColor: "transparent",
              backgroundClip: "text",
            }}>
              4 Simple Steps
            </span>
          </h2>
          <p className="text-gray-400 max-w-md mx-auto">
            Buying ranks and money has never been easier. Follow these simple steps to get started.
          </p>
        </div>

        {/* Steps */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 relative">
          {/* Connecting line (desktop only) */}
          <div className="hidden lg:block absolute top-10 left-[12.5%] right-[12.5%] h-px"
            style={{ background: "linear-gradient(90deg, transparent, rgba(168,85,247,0.3), transparent)" }} />

          {steps.map((s, i) => (
            <div
              key={s.step}
              className="fade-up flex flex-col items-center text-center gap-4 relative"
              style={{ animationDelay: `${i * 120}ms` }}
            >
              {/* Step number circle */}
              <div className="relative">
                <div className="w-20 h-20 rounded-full flex items-center justify-center text-3xl z-10 relative"
                  style={{
                    background: `linear-gradient(135deg, ${s.color}20, ${s.color}10)`,
                    border: `2px solid ${s.color}50`,
                    boxShadow: `0 0 20px ${s.color}20`,
                  }}>
                  {s.icon}
                </div>
                <div className="absolute -top-2 -right-2 w-7 h-7 rounded-full flex items-center justify-center text-xs font-black text-white"
                  style={{ background: s.color }}>
                  {s.step}
                </div>
              </div>

              <div>
                <h3 className="text-white font-bold text-base mb-2" style={{ fontFamily: "'Exo 2', sans-serif" }}>
                  {s.title}
                </h3>
                <p className="text-gray-400 text-sm leading-relaxed">{s.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
