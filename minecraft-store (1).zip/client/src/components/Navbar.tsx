/* ============================================================
   Navbar — DonutCraft Store
   Design: Sticky translucent dark nav with purple accent
   ============================================================ */
import { useState } from "react";
import { ShoppingCart, Menu, X, Sword, Coins } from "lucide-react";
import { useCart } from "@/contexts/CartContext";

interface NavbarProps {
  activeCategory: "ranks" | "money";
  onCategoryChange: (cat: "ranks" | "money") => void;
}

export default function Navbar({ activeCategory, onCategoryChange }: NavbarProps) {
  const { totalItems, setIsOpen } = useCart();
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <nav className="sticky top-0 z-50 w-full" style={{
      background: "rgba(10,10,18,0.85)",
      backdropFilter: "blur(16px)",
      borderBottom: "1px solid rgba(255,255,255,0.06)",
    }}>
      {/* Announcement ticker */}
      <div className="overflow-hidden py-1.5" style={{ background: "linear-gradient(90deg, #7c3aed, #9333ea, #7c3aed)" }}>
        <div className="flex whitespace-nowrap ticker-track">
          {Array(4).fill(null).map((_, i) => (
            <span key={i} className="flex items-center gap-6 px-4 text-white text-xs font-semibold tracking-wide">
              <span>🔥 NEW RANKS AVAILABLE</span>
              <span>💰 MONEY PACKAGES UP TO 60% OFF</span>
              <span>⚡ INSTANT DELIVERY</span>
              <span>🛡️ SECURE CHECKOUT</span>
              <span>🎮 JOIN DONUTCRAFT.NET</span>
            </span>
          ))}
        </div>
      </div>

      <div className="container mx-auto px-4 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg flex items-center justify-center text-white font-black text-lg"
              style={{ background: "linear-gradient(135deg, #7c3aed, #9333ea)" }}>
              🍩
            </div>
            <div>
              <span className="text-white font-black text-xl tracking-tight" style={{ fontFamily: "'Exo 2', sans-serif" }}>
                Donut<span style={{ color: "#a855f7" }}>Craft</span>
              </span>
              <div className="text-xs text-gray-400 -mt-0.5 hidden sm:block">Store</div>
            </div>
          </div>

          {/* Desktop nav */}
          <div className="hidden md:flex items-center gap-1">
            <button
              onClick={() => onCategoryChange("ranks")}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-semibold transition-all ${
                activeCategory === "ranks"
                  ? "text-white"
                  : "text-gray-400 hover:text-white"
              }`}
              style={activeCategory === "ranks" ? {
                background: "linear-gradient(135deg, rgba(124,58,237,0.3), rgba(147,51,234,0.2))",
                border: "1px solid rgba(168,85,247,0.4)",
              } : {}}
            >
              <Sword size={15} />
              Ranks
            </button>
            <button
              onClick={() => onCategoryChange("money")}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-semibold transition-all ${
                activeCategory === "money"
                  ? "text-white"
                  : "text-gray-400 hover:text-white"
              }`}
              style={activeCategory === "money" ? {
                background: "linear-gradient(135deg, rgba(124,58,237,0.3), rgba(147,51,234,0.2))",
                border: "1px solid rgba(168,85,247,0.4)",
              } : {}}
            >
              <span className="text-sm">💰</span>
              Money
            </button>
          </div>

          {/* Right side */}
          <div className="flex items-center gap-3">
            {/* Server IP */}
            <div className="hidden lg:flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs"
              style={{ background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.08)" }}>
              <span className="w-2 h-2 rounded-full bg-green-400 animate-pulse"></span>
              <span className="text-gray-300 font-mono">donutcraft.net</span>
            </div>

            {/* Cart button */}
            <button
              onClick={() => setIsOpen(true)}
              className="relative flex items-center gap-2 px-4 py-2 rounded-lg text-white text-sm font-semibold btn-glow"
            >
              <ShoppingCart size={16} />
              <span className="hidden sm:inline">Cart</span>
              {totalItems > 0 && (
                <span className="absolute -top-2 -right-2 w-5 h-5 rounded-full text-white text-xs font-bold flex items-center justify-center"
                  style={{ background: "#22c55e" }}>
                  {totalItems}
                </span>
              )}
            </button>

            {/* Mobile menu toggle */}
            <button
              className="md:hidden text-gray-400 hover:text-white p-2"
              onClick={() => setMobileOpen(!mobileOpen)}
            >
              {mobileOpen ? <X size={20} /> : <Menu size={20} />}
            </button>
          </div>
        </div>

        {/* Mobile menu */}
        {mobileOpen && (
          <div className="md:hidden pb-4 flex flex-col gap-2">
            <button
              onClick={() => { onCategoryChange("ranks"); setMobileOpen(false); }}
              className={`flex items-center gap-2 px-4 py-3 rounded-lg text-sm font-semibold transition-all ${
                activeCategory === "ranks" ? "text-white" : "text-gray-400"
              }`}
              style={activeCategory === "ranks" ? {
                background: "rgba(124,58,237,0.2)",
                border: "1px solid rgba(168,85,247,0.3)",
              } : {}}
            >
              <Sword size={15} />
              Ranks
            </button>
            <button
              onClick={() => { onCategoryChange("money"); setMobileOpen(false); }}
              className={`flex items-center gap-2 px-4 py-3 rounded-lg text-sm font-semibold transition-all ${
                activeCategory === "money" ? "text-white" : "text-gray-400"
              }`}
              style={activeCategory === "money" ? {
                background: "rgba(124,58,237,0.2)",
                border: "1px solid rgba(168,85,247,0.3)",
              } : {}}
            >
              <span>💰</span>
              Money
            </button>
          </div>
        )}
      </div>
    </nav>
  );
}
