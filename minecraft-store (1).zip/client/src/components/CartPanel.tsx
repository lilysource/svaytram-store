/* ============================================================
   CartPanel — DonutCraft Store
   Design: Slide-in dark panel from the right
   ============================================================ */
import { X, ShoppingCart, Trash2, Plus, Minus } from "lucide-react";
import { useCart } from "@/contexts/CartContext";
import { useLocation } from "wouter";
import { toast } from "sonner";

export default function CartPanel() {
  const { items, isOpen, setIsOpen, removeItem, updateQuantity, totalPrice } = useCart();
  const [, setLocation] = useLocation();

  if (!isOpen) return null;

  const handleCheckout = () => {
    if (items.length === 0) {
      toast.error("Your cart is empty");
      return;
    }
    setIsOpen(false);
    setLocation("/checkout");
  };

  return (
    <>
      {/* Backdrop */}
      <div
        className="fixed inset-0 z-40"
        style={{ background: "rgba(0,0,0,0.6)", backdropFilter: "blur(4px)" }}
        onClick={() => setIsOpen(false)}
      />

      {/* Panel */}
      <div
        className="fixed right-0 top-0 h-full z-50 flex flex-col cart-panel"
        style={{
          width: "min(420px, 100vw)",
          background: "linear-gradient(180deg, #0e0e1a 0%, #0a0a14 100%)",
          borderLeft: "1px solid rgba(168,85,247,0.2)",
          boxShadow: "-8px 0 40px rgba(0,0,0,0.6)",
        }}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-5 border-b border-white/5">
          <div className="flex items-center gap-3">
            <ShoppingCart size={20} className="text-purple-400" />
            <h2 className="text-white font-black text-xl" style={{ fontFamily: "'Exo 2', sans-serif" }}>
              Your Cart
            </h2>
            {items.length > 0 && (
              <span className="px-2 py-0.5 rounded-full text-xs font-bold text-white"
                style={{ background: "linear-gradient(135deg, #7c3aed, #9333ea)" }}>
                {items.length}
              </span>
            )}
          </div>
          <button
            onClick={() => setIsOpen(false)}
            className="text-gray-400 hover:text-white transition-colors p-1.5 rounded-lg hover:bg-white/5"
          >
            <X size={20} />
          </button>
        </div>

        {/* Items */}
        <div className="flex-1 overflow-y-auto px-6 py-4 flex flex-col gap-3">
          {items.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full gap-4 text-center">
              <div className="text-6xl">🛒</div>
              <div>
                <p className="text-white font-bold text-lg" style={{ fontFamily: "'Exo 2', sans-serif" }}>
                  Your cart is empty
                </p>
                <p className="text-gray-400 text-sm mt-1">Add some ranks or money packages!</p>
              </div>
            </div>
          ) : (
            items.map((item) => (
              <div
                key={item.id}
                className="flex gap-3 p-3 rounded-xl"
                style={{
                  background: "rgba(255,255,255,0.04)",
                  border: "1px solid rgba(255,255,255,0.06)",
                }}
              >
                <img
                  src={item.image}
                  alt={item.name}
                  className="w-16 h-16 rounded-lg object-cover shrink-0"
                />
                <div className="flex-1 min-w-0">
                  <p className="text-white font-bold text-sm truncate" style={{ fontFamily: "'Exo 2', sans-serif" }}>
                    {item.name}
                  </p>
                  <p className="text-purple-400 font-black text-lg" style={{ fontFamily: "'Exo 2', sans-serif" }}>
                    ${(item.price * item.quantity).toFixed(2)}
                  </p>
                  <div className="flex items-center gap-2 mt-1.5">
                    <button
                      onClick={() => updateQuantity(item.id, item.quantity - 1)}
                      className="w-6 h-6 rounded flex items-center justify-center text-gray-400 hover:text-white hover:bg-white/10 transition-all"
                    >
                      <Minus size={12} />
                    </button>
                    <span className="text-white text-sm font-bold w-4 text-center">{item.quantity}</span>
                    <button
                      onClick={() => updateQuantity(item.id, item.quantity + 1)}
                      className="w-6 h-6 rounded flex items-center justify-center text-gray-400 hover:text-white hover:bg-white/10 transition-all"
                    >
                      <Plus size={12} />
                    </button>
                  </div>
                </div>
                <button
                  onClick={() => removeItem(item.id)}
                  className="text-gray-500 hover:text-red-400 transition-colors p-1 self-start"
                >
                  <Trash2 size={15} />
                </button>
              </div>
            ))
          )}
        </div>

        {/* Footer */}
        {items.length > 0 && (
          <div className="px-6 py-5 border-t border-white/5 flex flex-col gap-3">
            {/* Total */}
            <div className="flex items-center justify-between">
              <span className="text-gray-400 font-medium">Total</span>
              <span className="text-white font-black text-2xl" style={{ fontFamily: "'Exo 2', sans-serif" }}>
                ${totalPrice.toFixed(2)} <span className="text-sm font-normal text-gray-400">USD</span>
              </span>
            </div>

            {/* Checkout button */}
            <button
              onClick={handleCheckout}
              className="w-full py-3.5 rounded-xl text-white font-black text-base btn-glow transition-all"
              style={{ fontFamily: "'Exo 2', sans-serif" }}
            >
              Proceed to Checkout →
            </button>

            {/* Continue shopping */}
            <button
              onClick={() => setIsOpen(false)}
              className="w-full py-2 text-gray-500 hover:text-white text-sm font-medium transition-colors"
            >
              Continue shopping
            </button>

            {/* Security note */}
            <div className="flex items-center justify-center gap-2 text-xs text-gray-500">
              <span>🔒</span>
              <span>Secure checkout powered by Stripe</span>
            </div>
          </div>
        )}
      </div>
    </>
  );
}
