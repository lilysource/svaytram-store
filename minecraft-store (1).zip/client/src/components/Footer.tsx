/* ============================================================
   Footer — DonutCraft Store
   Design: Dark footer with links and server info
   ============================================================ */

export default function Footer() {
  return (
    <footer style={{
      background: "rgba(0,0,0,0.4)",
      borderTop: "1px solid rgba(255,255,255,0.05)",
    }}>
      <div className="container mx-auto px-4 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-10">
          {/* Brand */}
          <div className="md:col-span-2">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-xl flex items-center justify-center text-white font-black text-xl"
                style={{ background: "linear-gradient(135deg, #7c3aed, #9333ea)" }}>
                🍩
              </div>
              <div>
                <span className="text-white font-black text-xl" style={{ fontFamily: "'Exo 2', sans-serif" }}>
                  Donut<span style={{ color: "#a855f7" }}>Craft</span>
                </span>
                <div className="text-xs text-gray-500">Store</div>
              </div>
            </div>
            <p className="text-gray-400 text-sm leading-relaxed max-w-xs">
              The #1 Minecraft rank and money store. Fast delivery, secure checkout, and 24/7 support.
            </p>
            <div className="flex items-center gap-2 mt-4 px-3 py-2 rounded-lg w-fit"
              style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.07)" }}>
              <span className="w-2 h-2 rounded-full bg-green-400 animate-pulse"></span>
              <span className="text-gray-300 text-xs font-mono">donutcraft.net</span>
            </div>
          </div>

          {/* Store links */}
          <div>
            <h4 className="text-white font-bold text-sm mb-4" style={{ fontFamily: "'Exo 2', sans-serif" }}>Store</h4>
            <ul className="flex flex-col gap-2">
              {["Ranks", "In-Game Money", "Packages", "Sale Items"].map((link) => (
                <li key={link}>
                  <a href="#" className="text-gray-400 hover:text-purple-400 text-sm transition-colors">{link}</a>
                </li>
              ))}
            </ul>
          </div>

          {/* Support links */}
          <div>
            <h4 className="text-white font-bold text-sm mb-4" style={{ fontFamily: "'Exo 2', sans-serif" }}>Support</h4>
            <ul className="flex flex-col gap-2">
              {["Discord Support", "Terms of Service", "Privacy Policy", "Refund Policy"].map((link) => (
                <li key={link}>
                  <a href="#" className="text-gray-400 hover:text-purple-400 text-sm transition-colors">{link}</a>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-6 border-t border-white/5">
          <p className="text-gray-500 text-xs">
            © 2026 DonutCraft Store. All rights reserved.
          </p>
          <p className="text-gray-600 text-xs text-center">
            This store is not affiliated with or endorsed by Mojang Studios or Microsoft.
          </p>
        </div>
      </div>
    </footer>
  );
}
