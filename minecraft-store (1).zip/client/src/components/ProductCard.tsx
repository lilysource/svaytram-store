/* ============================================================
   ProductCard — DonutCraft Store
   Design: Dark card with purple glow on hover, tier-colored border
   ============================================================ */
import { ShoppingCart, Star, Check, Clock, DollarSign } from "lucide-react";
import { useCart } from "@/contexts/CartContext";
import type { Product } from "@/lib/storeData";
import { toast } from "sonner";

interface ProductCardProps {
  product: Product;
  index?: number;
}

const tierColors: Record<string, { border: string; glow: string; badge: string; text: string }> = {
  vip: {
    border: "#f59e0b",
    glow: "rgba(245,158,11,0.2)",
    badge: "linear-gradient(135deg, #f59e0b, #d97706)",
    text: "#fbbf24",
  },
  mvp: {
    border: "#06b6d4",
    glow: "rgba(6,182,212,0.2)",
    badge: "linear-gradient(135deg, #06b6d4, #0284c7)",
    text: "#22d3ee",
  },
  elite: {
    border: "#a855f7",
    glow: "rgba(168,85,247,0.2)",
    badge: "linear-gradient(135deg, #a855f7, #7c3aed)",
    text: "#c084fc",
  },
  legend: {
    border: "#f97316",
    glow: "rgba(249,115,22,0.2)",
    badge: "linear-gradient(135deg, #f97316, #dc2626)",
    text: "#fb923c",
  },
};

export default function ProductCard({ product, index = 0 }: ProductCardProps) {
  const { addItem } = useCart();
  const tierColor = product.tier ? tierColors[product.tier] : null;

  const handleAddToCart = () => {
    addItem({
      id: product.id,
      name: product.duration ? `${product.name} (${product.duration})` : product.name,
      price: product.price,
      originalPrice: product.originalPrice,
      image: product.image,
      category: product.category,
    });
    toast.success(`Added to cart!`, {
      description: product.duration ? `${product.name} — ${product.duration}` : product.name,
      duration: 2000,
    });
  };

  const discount = product.originalPrice
    ? Math.round((1 - product.price / product.originalPrice) * 100)
    : 0;

  return (
    <div
      className="fade-up rounded-xl overflow-hidden flex flex-col relative group"
      style={{
        animationDelay: `${index * 80}ms`,
        background: "linear-gradient(145deg, rgba(20,20,35,0.95), rgba(15,15,28,0.98))",
        border: `1px solid ${tierColor ? tierColor.border + "40" : "rgba(255,255,255,0.07)"}`,
        transition: "all 0.3s ease",
      }}
      onMouseEnter={(e) => {
        const el = e.currentTarget;
        el.style.transform = "translateY(-6px)";
        el.style.borderColor = tierColor ? tierColor.border + "80" : "rgba(168,85,247,0.5)";
        el.style.boxShadow = `0 12px 40px ${tierColor ? tierColor.glow : "rgba(124,58,237,0.2)"}, 0 0 0 1px ${tierColor ? tierColor.border + "30" : "rgba(168,85,247,0.2)"}`;
      }}
      onMouseLeave={(e) => {
        const el = e.currentTarget;
        el.style.transform = "translateY(0)";
        el.style.borderColor = tierColor ? tierColor.border + "40" : "rgba(255,255,255,0.07)";
        el.style.boxShadow = "none";
      }}
    >
      {/* Badges */}
      <div className="absolute top-3 left-3 flex flex-col gap-1.5 z-10">
        {product.popular && (
          <span className="flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold text-white"
            style={{ background: "linear-gradient(135deg, #7c3aed, #9333ea)" }}>
            <Star size={10} fill="white" />
            POPULAR
          </span>
        )}
        {product.sale && discount > 0 && (
          <span className="px-2.5 py-1 rounded-full text-xs font-bold text-white sale-badge">
            -{discount}% OFF
          </span>
        )}
      </div>

      {/* Tier badge */}
      {product.tier && tierColor && (
        <div className="absolute top-3 right-3 z-10">
          <span className="px-2.5 py-1 rounded-full text-xs font-black text-white"
            style={{ backgroundImage: tierColor.badge }}>
            {product.tier.toUpperCase()}
          </span>
        </div>
      )}

      {/* Product image */}
      <div className="relative overflow-hidden" style={{ height: "180px", background: "rgba(0,0,0,0.3)" }}>
        <img
          src={product.image}
          alt={product.name}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
        />
        <div className="absolute inset-0" style={{
          background: "linear-gradient(to top, rgba(15,15,28,0.8) 0%, transparent 60%)"
        }} />
      </div>

      {/* Content */}
      <div className="flex flex-col flex-1 p-4 gap-3">
        {/* Title + duration/amount */}
        <div>
          <div className="flex items-center gap-2 mb-1">
            <h3 className="text-white font-black text-lg leading-tight" style={{ fontFamily: "'Exo 2', sans-serif", margin: 0 }}>
              {product.name}
            </h3>
          </div>
          {product.duration && (
            <div className="flex items-center gap-1.5 text-xs font-semibold" style={{ color: tierColor?.text || "#a855f7" }}>
              <Clock size={11} />
              {product.duration}
            </div>
          )}
          {product.amount && (
            <div className="flex items-center gap-1.5 text-xs font-semibold text-yellow-400">
              <DollarSign size={11} />
              {product.amount} in-game
            </div>
          )}
        </div>

        <p className="text-gray-400 text-xs leading-relaxed flex-1">{product.description}</p>

        {/* Perks */}
        {product.perks && (
          <ul className="flex flex-col gap-1">
            {product.perks.slice(0, 4).map((perk) => (
              <li key={perk} className="flex items-center gap-2 text-xs text-gray-300">
                <Check size={11} className="text-green-400 shrink-0" />
                {perk}
              </li>
            ))}
            {product.perks.length > 4 && (
              <li className="text-xs text-gray-500">+{product.perks.length - 4} more perks</li>
            )}
          </ul>
        )}

        {/* Price + Add to cart */}
        <div className="flex items-center justify-between pt-2 border-t border-white/5">
          <div>
            <div className="flex items-baseline gap-2">
              <span className="text-2xl font-black text-white" style={{ fontFamily: "'Exo 2', sans-serif" }}>
                ${product.price.toFixed(2)}
              </span>
              {product.originalPrice && (
                <span className="text-sm text-gray-500 line-through">${product.originalPrice.toFixed(2)}</span>
              )}
            </div>
            <div className="text-xs text-gray-500">USD</div>
          </div>

          <button
            onClick={handleAddToCart}
            className="flex items-center gap-2 px-4 py-2.5 rounded-lg text-sm font-bold text-white transition-all active:scale-95"
            style={{
              backgroundImage: "linear-gradient(135deg, #7c3aed, #9333ea)",
              boxShadow: "0 4px 12px rgba(124,58,237,0.4)",
            }}
            onMouseEnter={(e) => {
              (e.currentTarget as HTMLButtonElement).style.boxShadow = "0 6px 20px rgba(124,58,237,0.6)";
              (e.currentTarget as HTMLButtonElement).style.transform = "translateY(-1px)";
            }}
            onMouseLeave={(e) => {
              (e.currentTarget as HTMLButtonElement).style.boxShadow = "0 4px 12px rgba(124,58,237,0.4)";
              (e.currentTarget as HTMLButtonElement).style.transform = "translateY(0)";
            }}
          >
            <ShoppingCart size={14} />
            Buy
          </button>
        </div>
      </div>
    </div>
  );
}
