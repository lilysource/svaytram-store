/* ============================================================
   FAQSection — DonutCraft Store
   Design: Accordion FAQ with purple accent
   ============================================================ */
import { useState } from "react";
import { ChevronDown } from "lucide-react";

const faqs = [
  {
    q: "How do I receive my product after purchase?",
    a: "Money orders are delivered automatically to your in-game account within minutes. For rank packages, please join our Discord server and open a support ticket — our staff team will help you shortly.",
  },
  {
    q: "How long does delivery take?",
    a: "Money packages are delivered instantly (within 1-5 minutes). Rank packages are delivered within 1-10 minutes during active hours. We are available 24/7 to ensure fast delivery.",
  },
  {
    q: "What payment methods do you accept?",
    a: "We accept all major credit/debit cards (Visa, Mastercard, Amex), PayPal, and various local payment methods. All transactions are secured with SSL encryption.",
  },
  {
    q: "Do you provide refunds?",
    a: "Refunds will be issued only if the issue is determined to be on our end (e.g., delivery failure). If the issue is not caused by us, we are unable to provide a refund. We strive to ensure the best service.",
  },
  {
    q: "Is this safe? Will I get banned?",
    a: "All our products are 100% safe and comply with server rules. We have never had a player banned for purchasing from our store. Your account security is our top priority.",
  },
  {
    q: "Do you offer support?",
    a: "Absolutely! Our support team is available 24/7 on our Discord server. Simply create a ticket and a staff member will assist you as quickly as possible.",
  },
];

function FAQItem({ q, a, isOpen, onToggle }: { q: string; a: string; isOpen: boolean; onToggle: () => void }) {
  return (
    <div
      className="rounded-xl overflow-hidden transition-all"
      style={{
        background: isOpen ? "rgba(124,58,237,0.08)" : "rgba(20,20,35,0.6)",
        border: `1px solid ${isOpen ? "rgba(168,85,247,0.3)" : "rgba(255,255,255,0.06)"}`,
      }}
    >
      <button
        onClick={onToggle}
        className="w-full flex items-center justify-between px-5 py-4 text-left gap-4"
      >
        <span className="text-white font-semibold text-sm" style={{ fontFamily: "'Exo 2', sans-serif" }}>
          {q}
        </span>
        <ChevronDown
          size={18}
          className="text-purple-400 shrink-0 transition-transform duration-300"
          style={{ transform: isOpen ? "rotate(180deg)" : "rotate(0deg)" }}
        />
      </button>
      {isOpen && (
        <div className="px-5 pb-4">
          <p className="text-gray-400 text-sm leading-relaxed">{a}</p>
        </div>
      )}
    </div>
  );
}

export default function FAQSection() {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  return (
    <section className="py-20" style={{ background: "rgba(0,0,0,0.15)" }}>
      <div className="container mx-auto px-4 lg:px-8">
        <div className="max-w-3xl mx-auto">
          {/* Header */}
          <div className="text-center mb-10">
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-semibold text-purple-300 mb-4"
              style={{ background: "rgba(124,58,237,0.15)", border: "1px solid rgba(168,85,247,0.25)" }}>
              FAQ
            </div>
            <h2 className="text-3xl md:text-4xl font-black text-white mb-3" style={{ fontFamily: "'Exo 2', sans-serif" }}>
              Frequently Asked{" "}
              <span style={{
                backgroundImage: "linear-gradient(135deg, #a855f7, #7c3aed)",
                WebkitBackgroundClip: "text",
                WebkitTextFillColor: "transparent",
                backgroundClip: "text",
              }}>
                Questions
              </span>
            </h2>
            <p className="text-gray-400">Common questions about our services.</p>
          </div>

          {/* FAQ items */}
          <div className="flex flex-col gap-3">
            {faqs.map((faq, i) => (
              <FAQItem
                key={i}
                q={faq.q}
                a={faq.a}
                isOpen={openIndex === i}
                onToggle={() => setOpenIndex(openIndex === i ? null : i)}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
