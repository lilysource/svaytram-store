/* ============================================================
   FeaturesSection — DonutCraft Store
   Design: Dark cards with icon, title, description
   ============================================================ */

const features = [
  {
    icon: "⚡",
    title: "Instant Delivery",
    description: "Money packages are delivered automatically within minutes. Rank packages delivered within 1-10 minutes.",
    color: "#f59e0b",
  },
  {
    icon: "🔒",
    title: "Secure & Safe",
    description: "All transactions are encrypted and processed through trusted payment providers. Your data is always protected.",
    color: "#22c55e",
  },
  {
    icon: "🛡️",
    title: "24/7 Support",
    description: "Our dedicated support team is available around the clock via Discord to resolve any issues quickly.",
    color: "#06b6d4",
  },
  {
    icon: "💎",
    title: "Premium Quality",
    description: "All ranks and money packages are legitimate and comply with server rules. No bans, no risks.",
    color: "#a855f7",
  },
];

export default function FeaturesSection() {
  return (
    <section className="py-20" style={{ background: "rgba(0,0,0,0.2)" }}>
      <div className="container mx-auto px-4 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-semibold text-purple-300 mb-4"
            style={{ background: "rgba(124,58,237,0.15)", border: "1px solid rgba(168,85,247,0.25)" }}>
            Why Choose Us
          </div>
          <h2 className="text-3xl md:text-4xl font-black text-white mb-3" style={{ fontFamily: "'Exo 2', sans-serif" }}>
            Designed for the{" "}
            <span style={{
              backgroundImage: "linear-gradient(135deg, #a855f7, #7c3aed)",
              WebkitBackgroundClip: "text",
              WebkitTextFillColor: "transparent",
              backgroundClip: "text",
            }}>
              Best Quality
            </span>
          </h2>
          <p className="text-gray-400 max-w-lg mx-auto">
            We provide the safest, fastest, and most reliable Minecraft store experience.
          </p>
        </div>

        {/* Feature cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {features.map((f, i) => (
            <div
              key={f.title}
              className="fade-up p-6 rounded-xl flex flex-col gap-4 transition-all hover:-translate-y-1"
              style={{
                animationDelay: `${i * 100}ms`,
                background: "linear-gradient(145deg, rgba(20,20,35,0.8), rgba(15,15,28,0.9))",
                border: "1px solid rgba(255,255,255,0.06)",
              }}
            >
              <div className="w-12 h-12 rounded-xl flex items-center justify-center text-2xl"
                style={{ background: `${f.color}20`, border: `1px solid ${f.color}40` }}>
                {f.icon}
              </div>
              <div>
                <h3 className="text-white font-bold text-base mb-1.5" style={{ fontFamily: "'Exo 2', sans-serif" }}>
                  {f.title}
                </h3>
                <p className="text-gray-400 text-sm leading-relaxed">{f.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
