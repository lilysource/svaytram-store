export interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  originalPrice?: number;
  image: string;
  category: "rank" | "money";
  tier?: "vip" | "mvp" | "elite" | "legend";
  popular?: boolean;
  sale?: boolean;
  perks?: string[];
  duration?: string;
  amount?: string;
}

const HERO_IMG = "https://d2xsxph8kpxj0f.cloudfront.net/310519663529705089/CjSWRGtmeMHgCt37BQ525z/hero-banner-eV4nbVJQrfJ5QFcqaPGrdZ.webp";
const VIP_IMG = "https://d2xsxph8kpxj0f.cloudfront.net/310519663529705089/CjSWRGtmeMHgCt37BQ525z/rank-vip-YjH7DVdZPzZWqUzyLX2xKy.webp";
const MVP_IMG = "https://d2xsxph8kpxj0f.cloudfront.net/310519663529705089/CjSWRGtmeMHgCt37BQ525z/rank-mvp-ECkdWfLdR9qHN9dMyzTuCx.webp";
const LEGEND_IMG = "https://d2xsxph8kpxj0f.cloudfront.net/310519663529705089/CjSWRGtmeMHgCt37BQ525z/rank-legend-mnE3JG3JayMgwDtXdzy4n8.webp";
const MONEY_IMG = "https://d2xsxph8kpxj0f.cloudfront.net/310519663529705089/CjSWRGtmeMHgCt37BQ525z/money-coins-GhAPmNDUkBmi7bnVgojffi.webp";
const ELITE_IMG = "https://d2xsxph8kpxj0f.cloudfront.net/310519663529705089/CjSWRGtmeMHgCt37BQ525z/rank-elite-m8R7y4N8NmXwe3Fjz2wLwC.webp";

export { HERO_IMG };

export const rankProducts: Product[] = [
  {
    id: "rank-vip-30",
    name: "VIP Rank",
    description: "Access exclusive VIP perks, colored chat, and special commands for 30 days.",
    price: 4.99,
    image: VIP_IMG,
    category: "rank",
    tier: "vip",
    duration: "30 Days",
    perks: [
      "[VIP] prefix in chat",
      "Access to /fly in lobby",
      "3 Home slots",
      "Custom chat color",
      "Priority queue",
    ],
  },
  {
    id: "rank-vip-90",
    name: "VIP Rank",
    description: "Save more with 90 days of VIP access and all exclusive perks.",
    price: 11.99,
    originalPrice: 14.97,
    image: VIP_IMG,
    category: "rank",
    tier: "vip",
    duration: "90 Days",
    sale: true,
    perks: [
      "[VIP] prefix in chat",
      "Access to /fly in lobby",
      "3 Home slots",
      "Custom chat color",
      "Priority queue",
    ],
  },
  {
    id: "rank-mvp-30",
    name: "MVP Rank",
    description: "Unlock MVP status with diamond-tier perks and exclusive cosmetics.",
    price: 9.99,
    image: MVP_IMG,
    category: "rank",
    tier: "mvp",
    duration: "30 Days",
    popular: true,
    perks: [
      "[MVP] prefix in chat",
      "/fly everywhere",
      "6 Home slots",
      "Custom join message",
      "Exclusive MVP kit",
      "Priority queue",
      "Discord MVP role",
    ],
  },
  {
    id: "rank-mvp-90",
    name: "MVP Rank",
    description: "Best value — 90 days of MVP with all diamond-tier perks.",
    price: 24.99,
    originalPrice: 29.97,
    image: MVP_IMG,
    category: "rank",
    tier: "mvp",
    duration: "90 Days",
    sale: true,
    perks: [
      "[MVP] prefix in chat",
      "/fly everywhere",
      "6 Home slots",
      "Custom join message",
      "Exclusive MVP kit",
      "Priority queue",
      "Discord MVP role",
    ],
  },
  {
    id: "rank-elite-30",
    name: "ELITE Rank",
    description: "The elite tier — purple prestige with maximum in-game advantages.",
    price: 19.99,
    image: ELITE_IMG,
    category: "rank",
    tier: "elite",
    duration: "30 Days",
    perks: [
      "[ELITE] prefix in chat",
      "/fly + /speed",
      "10 Home slots",
      "Custom particle effects",
      "Exclusive ELITE kit",
      "Skip queue entirely",
      "Discord ELITE role",
      "Monthly bonus rewards",
    ],
  },
  {
    id: "rank-legend-30",
    name: "LEGEND Rank",
    description: "The ultimate rank. Fiery prestige, maximum perks, legendary status.",
    price: 34.99,
    image: LEGEND_IMG,
    category: "rank",
    tier: "legend",
    duration: "30 Days",
    perks: [
      "[LEGEND] prefix in chat",
      "All commands unlocked",
      "Unlimited homes",
      "Custom join fireworks",
      "Exclusive LEGEND kit",
      "Instant queue skip",
      "Discord LEGEND role",
      "Weekly bonus rewards",
      "Custom nickname colors",
    ],
  },
];

export const moneyProducts: Product[] = [
  {
    id: "money-10m",
    name: "10 Million",
    description: "A solid start — 10 million in-game coins delivered instantly.",
    price: 1.99,
    image: MONEY_IMG,
    category: "money",
    amount: "$10,000,000",
  },
  {
    id: "money-25m",
    name: "25 Million",
    description: "Boost your economy with 25 million coins.",
    price: 3.99,
    image: MONEY_IMG,
    category: "money",
    amount: "$25,000,000",
  },
  {
    id: "money-60m",
    name: "60 Million",
    description: "Great value pack — 60 million coins at a discounted rate.",
    price: 7.99,
    originalPrice: 11.97,
    image: MONEY_IMG,
    category: "money",
    sale: true,
    amount: "$60,000,000",
  },
  {
    id: "money-125m",
    name: "125 Million",
    description: "Dominate the economy with 125 million in-game coins.",
    price: 14.99,
    originalPrice: 24.99,
    image: MONEY_IMG,
    category: "money",
    sale: true,
    popular: true,
    amount: "$125,000,000",
  },
  {
    id: "money-250m",
    name: "250 Million",
    description: "Become a top player — 250 million coins at massive savings.",
    price: 24.99,
    originalPrice: 49.99,
    image: MONEY_IMG,
    category: "money",
    sale: true,
    amount: "$250,000,000",
  },
  {
    id: "money-500m",
    name: "500 Million",
    description: "Half a billion coins — rule the server economy completely.",
    price: 44.99,
    originalPrice: 99.99,
    image: MONEY_IMG,
    category: "money",
    sale: true,
    amount: "$500,000,000",
  },
  {
    id: "money-1b",
    name: "1 Billion",
    description: "The ultimate money package — 1 billion coins, maximum power.",
    price: 79.99,
    originalPrice: 199.99,
    image: MONEY_IMG,
    category: "money",
    sale: true,
    amount: "$1,000,000,000",
  },
];

export const allProducts = [...rankProducts, ...moneyProducts];
