/* ============================================================
   Checkout Page — DonutCraft Store (QR Code Payment)
   Design: Left form + Right QR code payment
   ============================================================ */
import { useState } from "react";
import { useCart } from "@/contexts/CartContext";
import { useLocation } from "wouter";
import { ArrowLeft, Minus, Plus, Upload } from "lucide-react";
import { toast } from "sonner";

export default function Checkout() {
  const { items, totalPrice, clearCart } = useCart();
  const [, setLocation] = useLocation();
  const [loading, setLoading] = useState(false);
  const [quantity, setQuantity] = useState(1);
  const [platform, setPlatform] = useState<"java" | "bedrock">("java");
  const [promoCode, setPromoCode] = useState("");
  const [discount, setDiscount] = useState(0);
  const [username, setUsername] = useState("");
  const [email, setEmail] = useState("");
  const [paymentProof, setPaymentProof] = useState<File | null>(null);

  const handleApplyPromo = () => {
    if (promoCode.toLowerCase() === "save10") {
      setDiscount(0.1);
      toast.success("Promo code applied! 10% off");
    } else if (promoCode.toLowerCase() === "save20") {
      setDiscount(0.2);
      toast.success("Promo code applied! 20% off");
    } else {
      toast.error("Invalid promo code");
      setDiscount(0);
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) {
        toast.error("File size must be less than 5MB");
        return;
      }
      setPaymentProof(file);
      toast.success("Payment proof uploaded!");
    }
  };

  const validateForm = () => {
    if (!username.trim()) {
      toast.error("Please enter your Minecraft username");
      return false;
    }
    if (!email.includes("@")) {
      toast.error("Please enter a valid email");
      return false;
    }
    if (!paymentProof) {
      toast.error("Please upload payment proof");
      return false;
    }
    return true;
  };

  const finalPrice = (totalPrice * quantity * (1 - discount)).toFixed(2);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateForm()) return;

    setLoading(true);
    try {
      const item = items[0];
      const orderId = `ORD-${Date.now()}`;
      const timestamp = new Date().toLocaleString();

      // Send email notification
      const emailResponse = await fetch("/api/trpc/orders.sendConfirmationEmail", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          json: {
            username,
            email,
            productName: item.name,
            price: finalPrice,
            platform,
            quantity,
            discount,
            orderId,
            timestamp,
          },
        }),
      });

      if (!emailResponse.ok) {
        console.warn("Email sending failed, but order will proceed");
      }

      toast.success("Order submitted! 🎉", {
        description: `Confirmation email sent to ${email}. Items will be delivered to ${username} within 1-10 minutes.`,
      });
      clearCart();
      setTimeout(() => setLocation("/"), 2000);
    } catch (error) {
      console.error("Order submission error:", error);
      toast.error("Order submission failed");
    } finally {
      setLoading(false);
    }
  };

  if (items.length === 0) {
    return (
      <div className="min-h-screen" style={{ background: "#0a0a14" }}>
        <div className="container mx-auto px-4 lg:px-8 py-20 text-center">
          <div className="text-6xl mb-4">🛒</div>
          <h1 className="text-3xl font-black text-white mb-3" style={{ fontFamily: "'Exo 2', sans-serif" }}>
            Your cart is empty
          </h1>
          <p className="text-gray-400 mb-6">Add some items before checking out!</p>
          <button
            onClick={() => setLocation("/")}
            className="flex items-center gap-2 px-6 py-3 rounded-xl text-white font-bold mx-auto"
            style={{ backgroundImage: "linear-gradient(135deg, #7c3aed, #9333ea)" }}
          >
            <ArrowLeft size={16} />
            Back to Store
          </button>
        </div>
      </div>
    );
  }

  const item = items[0];

  return (
    <div className="min-h-screen" style={{ background: "#0a0a14" }}>
      {/* Header */}
      <div className="border-b" style={{ borderColor: "rgba(255,255,255,0.1)" }}>
        <div className="container mx-auto px-4 lg:px-8 py-4 flex items-center gap-4">
          <button
            onClick={() => setLocation("/")}
            className="text-gray-400 hover:text-white transition-colors"
          >
            <ArrowLeft size={20} />
          </button>
          <h1 className="text-2xl font-black text-white" style={{ fontFamily: "'Exo 2', sans-serif" }}>
            Secure Checkout
          </h1>
        </div>
      </div>

      {/* Main content */}
      <div className="container mx-auto px-4 lg:px-8 py-12">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* LEFT SIDE - Form */}
          <div>
            {/* Product header */}
            <div className="mb-8 pb-8" style={{ borderBottom: "2px solid #ff6600" }}>
              <h2 className="text-4xl font-black text-white mb-4" style={{ fontFamily: "'Exo 2', sans-serif" }}>
                {item.name}
              </h2>
              <div className="flex items-center gap-4">
                <div className="text-5xl font-black text-orange-500">
                  ${finalPrice}
                </div>
                <div className="px-3 py-1 rounded-full text-sm font-bold text-green-400"
                  style={{ background: "rgba(34,197,94,0.1)", border: "1px solid rgba(34,197,94,0.3)" }}>
                  ✓ In stock
                </div>
              </div>
            </div>

            {/* Checkout form */}
            <form onSubmit={handleSubmit} className="space-y-8">
              {/* Quantity */}
              <div>
                <label className="text-gray-400 text-xs font-black uppercase tracking-wider block mb-3">
                  Quantity
                </label>
                <div className="flex items-center gap-4 w-fit">
                  <button
                    type="button"
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    className="w-10 h-10 flex items-center justify-center rounded-lg text-white"
                    style={{ background: "rgba(255,255,255,0.1)", border: "1px solid rgba(255,255,255,0.2)" }}
                  >
                    <Minus size={16} />
                  </button>
                  <div className="text-2xl font-black text-white w-12 text-center">{quantity}</div>
                  <button
                    type="button"
                    onClick={() => setQuantity(quantity + 1)}
                    className="w-10 h-10 flex items-center justify-center rounded-lg text-white"
                    style={{ background: "rgba(255,255,255,0.1)", border: "1px solid rgba(255,255,255,0.2)" }}
                  >
                    <Plus size={16} />
                  </button>
                </div>
              </div>

              {/* Minecraft username */}
              <div>
                <label className="text-gray-400 text-xs font-black uppercase tracking-wider block mb-3">
                  Minecraft Username
                </label>
                <input
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="Enter IGN"
                  className="w-full px-4 py-3 rounded-lg text-white text-base"
                  style={{
                    background: "rgba(255,255,255,0.05)",
                    border: "1px solid rgba(255,255,255,0.1)",
                  }}
                />
              </div>

              {/* Email */}
              <div>
                <label className="text-gray-400 text-xs font-black uppercase tracking-wider block mb-3">
                  Email Address
                </label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="your@email.com"
                  className="w-full px-4 py-3 rounded-lg text-white text-base"
                  style={{
                    background: "rgba(255,255,255,0.05)",
                    border: "1px solid rgba(255,255,255,0.1)",
                  }}
                />
              </div>

              {/* Platform selector */}
              <div>
                <label className="text-gray-400 text-xs font-black uppercase tracking-wider block mb-3">
                  Platform
                </label>
                <div className="grid grid-cols-2 gap-4">
                  <button
                    type="button"
                    onClick={() => setPlatform("java")}
                    className="py-4 rounded-lg font-bold text-lg transition-all"
                    style={{
                      background: platform === "java" ? "rgba(255,102,0,0.2)" : "rgba(255,255,255,0.05)",
                      border: platform === "java" ? "2px solid #ff6600" : "1px solid rgba(255,255,255,0.1)",
                      color: platform === "java" ? "#ff6600" : "#9ca3af",
                    }}
                  >
                    💻 JAVA
                  </button>
                  <button
                    type="button"
                    onClick={() => setPlatform("bedrock")}
                    className="py-4 rounded-lg font-bold text-lg transition-all"
                    style={{
                      background: platform === "bedrock" ? "rgba(255,102,0,0.2)" : "rgba(255,255,255,0.05)",
                      border: platform === "bedrock" ? "2px solid #ff6600" : "1px solid rgba(255,255,255,0.1)",
                      color: platform === "bedrock" ? "#ff6600" : "#9ca3af",
                    }}
                  >
                    📱 BEDROCK
                  </button>
                </div>
              </div>

              {/* Promo code */}
              <div>
                <label className="text-gray-400 text-xs font-black uppercase tracking-wider block mb-3">
                  Promo Code
                </label>
                <div className="flex gap-3">
                  <input
                    type="text"
                    value={promoCode}
                    onChange={(e) => setPromoCode(e.target.value)}
                    placeholder="Have a coupon?"
                    className="flex-1 px-4 py-3 rounded-lg text-white text-base"
                    style={{
                      background: "rgba(255,255,255,0.05)",
                      border: "1px solid rgba(255,255,255,0.1)",
                    }}
                  />
                  <button
                    type="button"
                    onClick={handleApplyPromo}
                    className="px-6 py-3 rounded-lg font-bold text-white"
                    style={{
                      background: "rgba(255,255,255,0.1)",
                      border: "1px solid rgba(255,255,255,0.2)",
                    }}
                  >
                    APPLY
                  </button>
                </div>
                {discount > 0 && (
                  <p className="text-green-400 text-sm mt-2">✓ {Math.round(discount * 100)}% discount applied</p>
                )}
              </div>
            </form>
          </div>

          {/* RIGHT SIDE - QR Code Payment */}
          <div>
            <div className="sticky top-8 space-y-6">
              {/* QR Code Section */}
              <div className="p-8 rounded-2xl" style={{ background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.1)" }}>
                <h3 className="text-gray-400 text-xs font-black uppercase tracking-wider mb-6 text-center">
                  Scan to Pay ({platform.toUpperCase()})
                </h3>

                {/* QR Code Display */}
                <div className="flex justify-center mb-8">
                  <div className="p-4 rounded-2xl" style={{ background: "white" }}>
                    <div className="w-48 h-48 flex items-center justify-center" style={{ background: "#f3f4f6" }}>
                      <svg viewBox="0 0 200 200" className="w-full h-full">
                        {/* Placeholder QR Code */}
                        <rect width="200" height="200" fill="white" />
                        <rect x="10" y="10" width="40" height="40" fill="black" />
                        <rect x="150" y="10" width="40" height="40" fill="black" />
                        <rect x="10" y="150" width="40" height="40" fill="black" />
                        {/* QR pattern */}
                        <circle cx="100" cy="100" r="15" fill="#ff6600" />
                        {/* Random pattern for demo */}
                        {Array.from({ length: 20 }).map((_, i) => (
                          <rect
                            key={i}
                            x={30 + (i % 5) * 30}
                            y={30 + Math.floor(i / 5) * 30}
                            width="8"
                            height="8"
                            fill={Math.random() > 0.5 ? "black" : "white"}
                          />
                        ))}
                      </svg>
                    </div>
                  </div>
                </div>

                {/* Total Due */}
                <div className="border-t" style={{ borderColor: "rgba(255,255,255,0.1)" }}>
                  <div className="pt-6 flex justify-between items-center">
                    <span className="text-gray-400 text-sm font-bold uppercase">Total Due</span>
                    <span className="text-4xl font-black text-orange-500">${finalPrice}</span>
                  </div>
                </div>
              </div>

              {/* Upload Payment Proof */}
              <div className="p-8 rounded-2xl" style={{ background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.1)" }}>
                <h3 className="text-gray-400 text-xs font-black uppercase tracking-wider mb-6">
                  Upload Payment Proof
                </h3>

                <label className="block cursor-pointer">
                  <div className="border-2 border-dashed rounded-xl p-8 text-center transition-all hover:border-orange-500"
                    style={{ borderColor: paymentProof ? "#ff6600" : "rgba(255,255,255,0.2)" }}>
                    <Upload size={32} className="mx-auto mb-3" style={{ color: paymentProof ? "#ff6600" : "#9ca3af" }} />
                    <p className="text-gray-400 text-sm font-semibold">
                      {paymentProof ? paymentProof.name : "Drop screenshot or click to browse"}
                    </p>
                    <p className="text-gray-500 text-xs mt-2">PNG, JPG, or PDF (Max 5MB)</p>
                  </div>
                  <input
                    type="file"
                    onChange={handleFileUpload}
                    accept="image/*,.pdf"
                    className="hidden"
                  />
                </label>
              </div>

              {/* Submit Button */}
              <button
                onClick={(e) => {
                  e.preventDefault();
                  handleSubmit(e as any);
                }}
                disabled={loading}
                className="w-full py-4 rounded-2xl font-black text-lg text-white transition-all disabled:opacity-50 flex items-center justify-center gap-2 relative overflow-hidden group hover:shadow-2xl"
                style={{
                  backgroundImage: loading ? "none" : "linear-gradient(135deg, #ff5500, #ff8c00)",
                  background: loading ? "rgba(255,255,255,0.1)" : undefined,
                  boxShadow: loading ? "none" : "0 0 30px rgba(255, 85, 0, 0.4), inset 0 0 20px rgba(255, 255, 255, 0.1)",
                }}
              >
                <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-300"
                  style={{
                    background: "radial-gradient(circle at center, rgba(255, 200, 100, 0.3) 0%, transparent 70%)",
                  }}
                />
                <span className="relative z-10 flex items-center justify-center gap-2">
                  {loading ? "Processing..." : "🛒 CONFIRM & PAY"}
                </span>
              </button>

              {/* Security Badge */}
              <div className="flex items-center justify-center gap-2 text-gray-400 text-xs">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
                </svg>
                <span>Secure & Encrypted</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
