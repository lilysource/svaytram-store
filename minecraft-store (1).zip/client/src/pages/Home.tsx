/* ============================================================
   Home Page — DonutCraft Store
   Design: Modern Gaming Store — deep black + purple/violet
   Fonts: Exo 2 (display) + DM Sans (body)
   Sections: Navbar, Hero, Features, Shop (Ranks/Money), Testimonials, FAQ, Footer
   ============================================================ */
import { useState, useRef } from "react";
import Navbar from "@/components/Navbar";
import HeroSection from "@/components/HeroSection";
import FeaturesSection from "@/components/FeaturesSection";
import ProductCard from "@/components/ProductCard";
import TestimonialsSection from "@/components/TestimonialsSection";
import FAQSection from "@/components/FAQSection";
import Footer from "@/components/Footer";
import CartPanel from "@/components/CartPanel";
import HowItWorksSection from "@/components/HowItWorksSection";
import { rankProducts, moneyProducts } from "@/lib/storeData";

export default function Home() {
  const [activeCategory, setActiveCategory] = useState<"ranks" | "money">("ranks");
  const shopRef = useRef<HTMLDivElement>(null);

  const handleShopNow = (cat: "ranks" | "money") => {
    setActiveCategory(cat);
    setTimeout(() => {
      shopRef.current?.scrollIntoView({ behavior: "smooth", block: "start" });
    }, 50);
  };

  const products = activeCategory === "ranks" ? rankProducts : moneyProducts;

  return (
    <div className="min-h-screen" style={{ background: "#0a0a14" }}>
      <Navbar activeCategory={activeCategory} onCategoryChange={setActiveCategory} />

      <HeroSection onShopNow={handleShopNow} />

      <FeaturesSection />

      <HowItWorksSection />

      {/* Shop Section */}
      <section ref={shopRef} className="py-16" id="shop">
        <div className="container mx-auto px-4 lg:px-8">
          {/* Section header */}
          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-8">
            <div>
              <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-semibold text-purple-300 mb-3"
                style={{ background: "rgba(124,58,237,0.15)", border: "1px solid rgba(168,85,247,0.25)" }}>
                {activeCategory === "ranks" ? "⚔️ Rank Packages" : "💰 Money Packages"}
              </div>
              <h2 className="text-3xl md:text-4xl font-black text-white" style={{ fontFamily: "'Exo 2', sans-serif" }}>
                {activeCategory === "ranks" ? (
                  <>Available <span style={{
                    backgroundImage: "linear-gradient(135deg, #a855f7, #7c3aed)",
                    WebkitBackgroundClip: "text",
                    WebkitTextFillColor: "transparent",
                    backgroundClip: "text",
                  }}>Ranks</span></>
                ) : (
                  <>In-Game <span style={{
                    backgroundImage: "linear-gradient(135deg, #f59e0b, #d97706)",
                    WebkitBackgroundClip: "text",
                    WebkitTextFillColor: "transparent",
                    backgroundClip: "text",
                  }}>Money</span></>
                )}
              </h2>
            </div>

            {/* Category tabs */}
            <div className="flex gap-2 p-1 rounded-xl" style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.06)" }}>
              <button
                onClick={() => setActiveCategory("ranks")}
                className={`flex items-center gap-2 px-5 py-2.5 rounded-lg text-sm font-bold transition-all ${
                  activeCategory === "ranks" ? "text-white" : "text-gray-400 hover:text-white"
                }`}
                style={activeCategory === "ranks" ? {
                  background: "linear-gradient(135deg, #7c3aed, #9333ea)",
                  boxShadow: "0 4px 12px rgba(124,58,237,0.4)",
                } : {}}
              >
                ⚔️ Ranks
              </button>
              <button
                onClick={() => setActiveCategory("money")}
                className={`flex items-center gap-2 px-5 py-2.5 rounded-lg text-sm font-bold transition-all ${
                  activeCategory === "money" ? "text-white" : "text-gray-400 hover:text-white"
                }`}
                style={activeCategory === "money" ? {
                  background: "linear-gradient(135deg, #d97706, #f59e0b)",
                  boxShadow: "0 4px 12px rgba(217,119,6,0.4)",
                } : {}}
              >
                💰 Money
              </button>
            </div>
          </div>

          {/* Product grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5 stagger-children">
            {products.map((product, i) => (
              <ProductCard key={product.id} product={product} index={i} />
            ))}
          </div>

          {/* Bottom note */}
          <div className="mt-8 p-4 rounded-xl text-center"
            style={{ background: "rgba(124,58,237,0.08)", border: "1px solid rgba(168,85,247,0.15)" }}>
            <p className="text-gray-400 text-sm">
              🔒 All purchases are <strong className="text-white">100% secure</strong> and delivered{" "}
              <strong className="text-white">instantly</strong>. Need help?{" "}
              <a href="#" className="text-purple-400 hover:text-purple-300 underline">Join our Discord</a>
            </p>
          </div>
        </div>
      </section>

      <TestimonialsSection />

      <FAQSection />

      {/* Discord CTA Section */}
      <section className="py-16">
        <div className="container mx-auto px-4 lg:px-8">
          <div className="relative rounded-2xl overflow-hidden p-8 md:p-12 text-center"
            style={{
              background: "linear-gradient(135deg, rgba(124,58,237,0.2), rgba(147,51,234,0.1))",
              border: "1px solid rgba(168,85,247,0.25)",
            }}>
            {/* Background glow */}
            <div className="absolute inset-0 pointer-events-none"
              style={{ background: "radial-gradient(ellipse at center, rgba(124,58,237,0.15) 0%, transparent 70%)" }} />

            <div className="relative">
              <div className="text-5xl mb-4">🎮</div>
              <h2 className="text-3xl md:text-4xl font-black text-white mb-3" style={{ fontFamily: "'Exo 2', sans-serif" }}>
                Join the Community
              </h2>
              <p className="text-gray-300 mb-6 max-w-md mx-auto">
                Connect with 2,500+ players, get support, and stay updated on new packages and sales.
              </p>
              <div className="flex flex-wrap justify-center gap-3">
                <button
                  className="flex items-center gap-2 px-6 py-3 rounded-xl text-white font-bold btn-glow"
                  style={{ fontFamily: "'Exo 2', sans-serif" }}
                  onClick={() => window.open("https://discord.gg/donutcraft", "_blank")}
                >
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0 12.64 12.64 0 0 0-.617-1.25.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057a.082.082 0 0 0 .031.057 19.9 19.9 0 0 0 5.993 3.03.078.078 0 0 0 .084-.028 14.09 14.09 0 0 0 1.226-1.994.076.076 0 0 0-.041-.106 13.107 13.107 0 0 1-1.872-.892.077.077 0 0 1-.008-.128 10.2 10.2 0 0 0 .372-.292.074.074 0 0 1 .077-.01c3.928 1.793 8.18 1.793 12.062 0a.074.074 0 0 1 .078.01c.12.098.246.198.373.292a.077.077 0 0 1-.006.127 12.299 12.299 0 0 1-1.873.892.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028 19.839 19.839 0 0 0 6.002-3.03.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.03z"/>
                  </svg>
                  Join Discord
                </button>
                <button
                  className="flex items-center gap-2 px-6 py-3 rounded-xl font-bold transition-all hover:bg-white/10"
                  style={{
                    background: "rgba(255,255,255,0.06)",
                    border: "1px solid rgba(255,255,255,0.12)",
                    color: "white",
                    fontFamily: "'Exo 2', sans-serif",
                  }}
                >
                  🎮 Play Now
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      <Footer />

      {/* Cart Panel */}
      <CartPanel />
    </div>
  );
}
