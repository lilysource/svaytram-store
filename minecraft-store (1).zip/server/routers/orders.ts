import { z } from "zod";
import { publicProcedure, router } from "../_core/trpc";
import { sendOrderConfirmation, sendAdminNotification, initializeEmailService } from "../email";

// Initialize email service on startup
initializeEmailService();

export const ordersRouter = router({
  sendConfirmationEmail: publicProcedure
    .input(
      z.object({
        username: z.string(),
        email: z.string().email(),
        productName: z.string(),
        price: z.string(),
        platform: z.enum(["java", "bedrock"]),
        quantity: z.number(),
        discount: z.number(),
        orderId: z.string(),
        timestamp: z.string(),
      })
    )
    .mutation(async ({ input }) => {
      try {
        // Send customer confirmation email
        const customerEmailSent = await sendOrderConfirmation({
          username: input.username,
          email: input.email,
          productName: input.productName,
          price: input.price,
          platform: input.platform,
          quantity: input.quantity,
          discount: input.discount,
          orderId: input.orderId,
          timestamp: input.timestamp,
        });

        // Send admin notification
        const adminEmailSent = await sendAdminNotification({
          username: input.username,
          email: input.email,
          productName: input.productName,
          price: input.price,
          platform: input.platform,
          quantity: input.quantity,
          discount: input.discount,
          orderId: input.orderId,
          timestamp: input.timestamp,
        });

        return {
          success: customerEmailSent,
          customerEmailSent,
          adminEmailSent,
          orderId: input.orderId,
        };
      } catch (error) {
        console.error("[Orders] Error sending confirmation email:", error);
        return {
          success: false,
          customerEmailSent: false,
          adminEmailSent: false,
          orderId: input.orderId,
        };
      }
    }),
});
