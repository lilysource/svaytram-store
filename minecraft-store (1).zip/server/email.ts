import nodemailer from "nodemailer";

// Email transporter configuration
let transporter: ReturnType<typeof nodemailer.createTransport> | null = null;

export function initializeEmailService() {
  // Gmail SMTP configuration
  // You need to set these environment variables:
  // GMAIL_USER: your-email@gmail.com
  // GMAIL_APP_PASSWORD: your-app-specific-password (from Google Account)
  
  if (!process.env.GMAIL_USER || !process.env.GMAIL_APP_PASSWORD) {
    console.warn("[Email] Gmail credentials not configured. Email sending disabled.");
    return null;
  }

  try {
    transporter = nodemailer.createTransport({
      service: "gmail",
      auth: {
        user: process.env.GMAIL_USER,
        pass: process.env.GMAIL_APP_PASSWORD,
      },
    });

    console.log("[Email] Gmail service initialized successfully");
    return transporter;
  } catch (error) {
    console.error("[Email] Failed to initialize Gmail service:", error);
    return null;
  }
}

export interface OrderDetails {
  username: string;
  email: string;
  productName: string;
  price: string;
  platform: "java" | "bedrock";
  quantity: number;
  discount: number;
  orderId: string;
  timestamp: string;
}

export async function sendOrderConfirmation(order: OrderDetails) {
  if (!transporter) {
    console.warn("[Email] Transporter not initialized. Skipping email.");
    return false;
  }

  const discountAmount = parseFloat(order.price) * order.discount;
  const finalPrice = (parseFloat(order.price) - discountAmount).toFixed(2);

  const htmlContent = `
    <!DOCTYPE html>
    <html>
      <head>
        <style>
          body { font-family: 'DM Sans', Arial, sans-serif; background: #0a0a14; color: #fff; }
          .container { max-width: 600px; margin: 0 auto; padding: 20px; background: #1a1a2e; border-radius: 12px; border: 1px solid rgba(255,102,0,0.3); }
          .header { text-align: center; margin-bottom: 30px; }
          .header h1 { color: #ff6600; margin: 0; font-size: 28px; }
          .order-details { background: rgba(255,102,0,0.1); padding: 20px; border-radius: 8px; margin: 20px 0; }
          .detail-row { display: flex; justify-content: space-between; margin: 10px 0; }
          .label { color: #9ca3af; }
          .value { color: #fff; font-weight: bold; }
          .price-section { background: rgba(124,58,237,0.1); padding: 15px; border-radius: 8px; margin: 20px 0; }
          .final-price { font-size: 24px; color: #ff6600; font-weight: bold; text-align: center; }
          .footer { text-align: center; margin-top: 30px; color: #9ca3af; font-size: 12px; }
          .button { display: inline-block; background: linear-gradient(135deg, #ff5500, #ff8c00); color: white; padding: 12px 24px; border-radius: 8px; text-decoration: none; margin-top: 20px; font-weight: bold; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1>🎮 DonutCraft Store</h1>
            <p style="margin: 5px 0; color: #9ca3af;">Order Confirmation</p>
          </div>

          <p>Hi <strong>${order.username}</strong>,</p>
          <p>Thank you for your purchase! Your order has been confirmed and is being processed.</p>

          <div class="order-details">
            <div class="detail-row">
              <span class="label">Order ID:</span>
              <span class="value">${order.orderId}</span>
            </div>
            <div class="detail-row">
              <span class="label">Product:</span>
              <span class="value">${order.productName}</span>
            </div>
            <div class="detail-row">
              <span class="label">Platform:</span>
              <span class="value">${order.platform.toUpperCase()}</span>
            </div>
            <div class="detail-row">
              <span class="label">Quantity:</span>
              <span class="value">${order.quantity}</span>
            </div>
            <div class="detail-row">
              <span class="label">Subtotal:</span>
              <span class="value">$${order.price}</span>
            </div>
            ${order.discount > 0 ? `
            <div class="detail-row">
              <span class="label">Discount (${Math.round(order.discount * 100)}%):</span>
              <span class="value" style="color: #22c55e;">-$${discountAmount.toFixed(2)}</span>
            </div>
            ` : ''}
          </div>

          <div class="price-section">
            <p style="margin: 0 0 10px 0; color: #9ca3af;">Total Amount:</p>
            <div class="final-price">$${finalPrice}</div>
          </div>

          <h3 style="color: #ff6600; margin-top: 20px;">📦 What's Next?</h3>
          <ul style="color: #d1d5db;">
            <li>Your payment proof has been received and verified</li>
            <li>Your ${order.productName} will be delivered within <strong>1-10 minutes</strong></li>
            <li>You'll receive another email when your order is complete</li>
            <li>Join our Discord for support: <strong>discord.gg/donutcraft</strong></li>
          </ul>

          <h3 style="color: #ff6600; margin-top: 20px;">❓ Need Help?</h3>
          <p>If you have any questions or issues, please:</p>
          <ul style="color: #d1d5db;">
            <li>Join our Discord server for instant support</li>
            <li>Reply to this email with your order ID</li>
            <li>Check our FAQ at donutcraft.net</li>
          </ul>

          <div style="text-align: center; margin-top: 30px;">
            <a href="https://discord.gg/donutcraft" class="button">Join Discord Support</a>
          </div>

          <div class="footer">
            <p>Order placed on: ${order.timestamp}</p>
            <p>© 2026 DonutCraft Store. All rights reserved.</p>
            <p>This is an automated email. Please do not reply directly.</p>
          </div>
        </div>
      </body>
    </html>
  `;

  try {
    await transporter.sendMail({
      from: process.env.GMAIL_USER,
      to: order.email,
      subject: `🎮 Order Confirmation - ${order.orderId}`,
      html: htmlContent,
      text: `Order Confirmation\n\nHi ${order.username},\n\nThank you for your purchase!\n\nOrder ID: ${order.orderId}\nProduct: ${order.productName}\nPlatform: ${order.platform.toUpperCase()}\nQuantity: ${order.quantity}\nTotal: $${finalPrice}\n\nYour order will be delivered within 1-10 minutes.\n\nJoin our Discord for support: discord.gg/donutcraft`,
    });

    console.log(`[Email] Order confirmation sent to ${order.email}`);
    return true;
  } catch (error) {
    console.error("[Email] Failed to send order confirmation:", error);
    return false;
  }
}

export async function sendAdminNotification(order: OrderDetails) {
  if (!transporter || !process.env.GMAIL_USER) {
    return false;
  }

  try {
    await transporter.sendMail({
      from: process.env.GMAIL_USER,
      to: process.env.GMAIL_USER, // Send to yourself
      subject: `🛒 New Order - ${order.orderId}`,
      html: `
        <h2>New Order Received</h2>
        <p><strong>Order ID:</strong> ${order.orderId}</p>
        <p><strong>Customer:</strong> ${order.username} (${order.email})</p>
        <p><strong>Product:</strong> ${order.productName}</p>
        <p><strong>Platform:</strong> ${order.platform.toUpperCase()}</p>
        <p><strong>Quantity:</strong> ${order.quantity}</p>
        <p><strong>Total:</strong> $${order.price}</p>
        <p><strong>Time:</strong> ${order.timestamp}</p>
      `,
    });

    console.log(`[Email] Admin notification sent`);
    return true;
  } catch (error) {
    console.error("[Email] Failed to send admin notification:", error);
    return false;
  }
}
